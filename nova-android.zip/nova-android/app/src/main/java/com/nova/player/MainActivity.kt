package com.nova.player

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.ExecutionException

class MainActivity : Activity() {
    private data class Track(val uri: String, val title: String)

    private val bg = Color.rgb(11, 11, 16)
    private val panel = Color.rgb(23, 23, 31)
    private val white = Color.rgb(244, 242, 250)
    private val muted = Color.rgb(153, 150, 166)
    private val accent = Color.rgb(198, 167, 255)
    private val tracks = mutableListOf<Track>()
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var nowTitle: TextView
    private lateinit var nowSub: TextView
    private lateinit var playButton: Button
    private lateinit var seek: SeekBar
    private lateinit var timeText: TextView
    private var controller: MediaController? = null
    private var controllerFuture: com.google.common.util.concurrent.ListenableFuture<MediaController>? = null
    private var seekTouched = false
    private val handler = Handler(Looper.getMainLooper())

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        uris.forEach { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            val key = uri.toString()
            if (tracks.none { it.uri == key }) tracks.add(Track(key, displayName(uri)))
        }
        saveTracks()
        renderTracks()
        if (controller != null && tracks.isNotEmpty()) {
            val selected = tracks.lastIndex
            setQueueAndPlay(selected)
        }
    }

    private val progressTick = object : Runnable {
        override fun run() {
            val c = controller
            if (c != null) {
                if (!seekTouched) {
                    val duration = c.duration.takeIf { it > 0 && it != C.TIME_UNSET } ?: 0L
                    val position = c.currentPosition.coerceAtLeast(0L)
                    seek.max = duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                    seek.progress = position.coerceAtMost(seek.max.toLong()).toInt()
                    timeText.text = "${formatTime(position)}  /  ${formatTime(duration)}"
                }
                updateNowPlaying()
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildUi()
        loadTracks()
        renderTracks()
        connectController()
        handler.post(progressTick)
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(22), dp(18), dp(22), dp(12))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "NOVA"
            textSize = 27f
            letterSpacing = 0.18f
            setTextColor(white)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val tag = TextView(this).apply {
            text = "  MUSIC PLAYER"
            textSize = 10f
            letterSpacing = 0.12f
            setTextColor(accent)
        }
        header.addView(brand)
        header.addView(tag)
        val add = button("＋  ADD MUSIC", accent, bg).apply { textSize = 12f }
        val addRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(add, LinearLayout.LayoutParams(0, dp(46), 1f))
        }
        add.setOnClickListener { picker.launch(arrayOf("audio/*")) }

        val nowCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(16))
            setBackgroundColor(panel)
        }
        val eyebrow = label("NOW PLAYING", 10f, accent).apply { letterSpacing = 0.14f }
        nowTitle = label("Choose a track", 21f, white).apply {
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 2
        }
        nowSub = label("Your music, your space", 13f, muted)
        seek = SeekBar(this).apply {
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(white)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(61, 58, 71))
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) timeText.text = "${formatTime(progress.toLong())}  /  ${formatTime((seekBar?.max ?: 0).toLong())}"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) { seekTouched = true }
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val c = controller
                    if (c != null) c.seekTo(seek.progress.toLong())
                    seekTouched = false
                }
            })
        }
        timeText = label("0:00  /  0:00", 11f, muted)
        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        val shuffleButton = button("SHUFFLE", white, panel).apply { textSize = 10f }
        val prev = button("|◀", white, panel).apply { textSize = 18f }
        playButton = button("▶", bg, accent).apply {
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
        }
        val next = button("▶|", white, panel).apply { textSize = 18f }
        val repeatButton = button("REPEAT", white, panel).apply { textSize = 10f }
        controls.addView(shuffleButton, LinearLayout.LayoutParams(0, dp(44), 1.1f).apply { marginEnd = dp(5) })
        controls.addView(prev, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(8) })
        controls.addView(playButton, LinearLayout.LayoutParams(dp(58), dp(58)).apply { marginEnd = dp(8) })
        controls.addView(next, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(5) })
        controls.addView(repeatButton, LinearLayout.LayoutParams(0, dp(44), 1.1f))

        nowCard.addView(eyebrow, margin(0, 0, 0, 9))
        nowCard.addView(nowTitle, margin(0, 0, 0, 4))
        nowCard.addView(nowSub, margin(0, 0, 0, 9))
        nowCard.addView(seek, margin(-dp(7), 0, -dp(7), 0))
        nowCard.addView(timeText, margin(0, 0, 0, 7))
        nowCard.addView(controls)

        val libraryHeader = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        val libraryTitle = label("YOUR LIBRARY", 12f, white).apply { letterSpacing = 0.12f }
        val count = label("LOCAL FILES", 10f, muted)
        libraryHeader.addView(libraryTitle, LinearLayout.LayoutParams(0, dp(38), 1f))
        libraryHeader.addView(count)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            isFillViewport = false
            addView(list)
        }
        root.addView(header, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(addRow, margin(0, dp(7), 0, dp(16)))
        root.addView(nowCard, margin(0, 0, 0, dp(12)))
        root.addView(libraryHeader)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        playButton.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            if (c.mediaItemCount == 0 && tracks.isNotEmpty()) setQueueAndPlay(0)
            else if (c.isPlaying) c.pause() else c.play()
            updateNowPlaying()
        }
        prev.setOnClickListener { controller?.let { if (it.hasPreviousMediaItem()) it.seekToPreviousMediaItem() else it.seekTo(0) } }
        next.setOnClickListener { controller?.let { if (it.hasNextMediaItem()) it.seekToNextMediaItem() else if (it.mediaItemCount > 0) it.seekTo(0) } }
        shuffleButton.setOnClickListener {
            controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled; shuffleButton.text = if (it.shuffleModeEnabled) "SHUFFLE ON" else "SHUFFLE" }
        }
        repeatButton.setOnClickListener {
            controller?.let {
                it.repeatMode = when (it.repeatMode) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }
                repeatButton.text = when (it.repeatMode) { Player.REPEAT_MODE_ALL -> "REPEAT ALL"; Player.REPEAT_MODE_ONE -> "REPEAT ONE"; else -> "REPEAT" }
            }
        }
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                controller?.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) = updateNowPlaying()
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = updateNowPlaying()
                    override fun onPlaybackStateChanged(playbackState: Int) = updateNowPlaying()
                })
                if (tracks.isNotEmpty()) {
                    val items = tracks.map { toMediaItem(it) }
                    controller?.setMediaItems(items)
                    controller?.prepare()
                }
                updateNowPlaying()
                renderTracks()
            } catch (_: ExecutionException) {
                nowSub.text = "Couldn't connect to audio service"
            } catch (_: Exception) {
                nowSub.text = "Audio service unavailable"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun setQueueAndPlay(index: Int) {
        val c = controller ?: return
        if (tracks.isEmpty()) return
        c.setMediaItems(tracks.map { toMediaItem(it) }, index.coerceIn(0, tracks.lastIndex), C.TIME_UNSET)
        c.prepare()
        c.play()
        updateNowPlaying()
        renderTracks()
    }

    private fun toMediaItem(track: Track): MediaItem = MediaItem.Builder()
        .setMediaId(track.uri)
        .setUri(Uri.parse(track.uri))
        .setMediaMetadata(MediaMetadata.Builder().setTitle(track.title).setArtist("NOVA Library").build())
        .build()

    private fun renderTracks() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        if (tracks.isEmpty()) {
            val empty = label("Your library is empty.\nTap ADD MUSIC to choose audio files from your phone.", 13f, muted)
            empty.setPadding(dp(4), dp(20), dp(4), dp(20))
            list.addView(empty)
            return
        }
        tracks.forEachIndexed { index, track ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(10), dp(10))
                setBackgroundColor(if (controller?.currentMediaItem?.mediaId == track.uri) Color.rgb(38, 32, 50) else panel)
            }
            val num = label(String.format(Locale.getDefault(), "%02d", index + 1), 11f, accent)
            val name = label(track.title, 14f, white).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
            val sub = label("LOCAL AUDIO", 9f, muted).apply { letterSpacing = 0.08f }
            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(name)
                addView(sub, margin(0, dp(3), 0, 0))
            }
            val more = label("•••", 16f, muted)
            row.addView(num, LinearLayout.LayoutParams(dp(32), -2))
            row.addView(textCol, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(more, LinearLayout.LayoutParams(dp(28), -2))
            row.setOnClickListener { setQueueAndPlay(index) }
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
        }
    }

    private fun updateNowPlaying() {
        val c = controller ?: return
        val item = c.currentMediaItem
        nowTitle.text = item?.mediaMetadata?.title?.toString() ?: "Choose a track"
        nowSub.text = if (item == null) "Your music, your space" else if (c.isPlaying) "NOW PLAYING · NOVA" else "READY WHEN YOU ARE"
        playButton.text = if (c.isPlaying) "Ⅱ" else "▶"
        if (!seekTouched) {
            val duration = c.duration.takeIf { it > 0 && it != C.TIME_UNSET } ?: 0L
            seek.max = duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt().coerceAtLeast(1)
            seek.progress = c.currentPosition.coerceAtMost(seek.max.toLong()).toInt()
            timeText.text = "${formatTime(c.currentPosition)}  /  ${formatTime(duration)}"
        }
    }

    private fun loadTracks() {
        tracks.clear()
        val raw = getSharedPreferences("nova", MODE_PRIVATE).getString("tracks", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                tracks.add(Track(obj.getString("uri"), obj.getString("title")))
            }
        } catch (_: Exception) { tracks.clear() }
    }

    private fun saveTracks() {
        val arr = JSONArray()
        tracks.forEach { arr.put(JSONObject().put("uri", it.uri).put("title", it.title)) }
        getSharedPreferences("nova", MODE_PRIVATE).edit().putString("tracks", arr.toString()).apply()
    }

    private fun displayName(uri: Uri): String {
        var result: String? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) result = cursor.getString(0)
            }
        } catch (_: Exception) { }
        return result ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Unknown track"
    }

    private fun label(text: String, size: Float, color: Int) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun button(text: String, textColor: Int, color: Int) = Button(this).apply {
        this.text = text
        setTextColor(textColor)
        setBackgroundColor(color)
        isAllCaps = false
        minHeight = 0
        minimumHeight = 0
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(6), 0, dp(6), 0)
        stateListAnimator = null
    }

    private fun margin(left: Int, top: Int, right: Int, bottom: Int) = LinearLayout.LayoutParams(-1, -2).apply {
        setMargins(left, top, right, bottom)
    }

    private fun formatTime(ms: Long): String {
        val total = (ms.coerceAtLeast(0L) / 1000L).toInt()
        return String.format(Locale.getDefault(), "%d:%02d", total / 60, total % 60)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(progressTick)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}
